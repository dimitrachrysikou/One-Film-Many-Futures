"""
preprocessing-script.py
One Film, Many Futures — House on Haunted Hill (1959) — Ομάδα 15

Δύο modes:
  1) extract_preprocess : τρέχει ffmpeg, εξάγει raw frames και υπολογίζει
     αυτόματα brightness / contrast / blur_edge_score / perceptual_hash /
     duplicate_distance, γράφοντας data/curation_log.csv (Βήμα 2).
  2) build_curated       : διαβάζει το (ήδη επιμελημένο, με final_decision
     συμπληρωμένο) curation_log.csv, αντιγράφει τα kept frames στο
     data/images/curated/, και παράγει data/metadata.csv + template
     data/annotations.csv (Βήμα 3-4), με τις ΠΡΑΓΜΑΤΙΚΕΣ στήλες που
     χρησιμοποιεί η ομάδα -- ΟΧΙ bounding boxes.
"""

import argparse
import os
import shutil
import subprocess
import sys

import pandas as pd
from PIL import Image
import numpy as np

def compute_average_hash(img_gray, hash_size=8):
    """Απλό average-hash (aHash) 8x8 -> hex string, για duplicate detection."""
    small = img_gray.resize((hash_size, hash_size), Image.LANCZOS)
    pixels = np.asarray(small, dtype=np.float64)
    avg = pixels.mean()
    bits = (pixels > avg).flatten()
    # bit array -> hex string
    bit_str = "".join("1" if b else "0" for b in bits)
    return f"{int(bit_str, 2):0{hash_size * hash_size // 4}x}"


def hamming_distance_hex(hash_a, hash_b):
    """Hamming distance μεταξύ δύο hex perceptual hashes."""
    int_a = int(hash_a, 16)
    int_b = int(hash_b, 16)
    return bin(int_a ^ int_b).count("1")


def compute_blur_edge_score(img_gray):
    """
    Απλό μέτρο blur/edge βασισμένο σε Laplacian-like gradient variance
    (χωρίς εξάρτηση από opencv· μόνο PIL/numpy).
    Χαμηλή τιμή -> πιθανώς θολό frame.
    """
    arr = np.asarray(img_gray, dtype=np.float64)
    gy, gx = np.gradient(arr)
    edge_map = np.sqrt(gx ** 2 + gy ** 2)
    return float(edge_map.var())


def extract_preprocess(args):
    print(f"--- Extracting & preprocessing: {args.video} (interval={args.interval}s) ---")

    raw_dir = "raw_frames"
    os.makedirs(raw_dir, exist_ok=True)

    pattern = os.path.join(raw_dir, f"{args.film_short}_raw_%06d.jpg")
    fps = f"1/{args.interval}"

    # 1) Εξαγωγή frames με ffmpeg
    cmd = ["ffmpeg", "-y", "-i", args.video, "-vf", f"fps={fps}", pattern]
    print("Εκτέλεση:", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("Σφάλμα ffmpeg:", result.stderr[-2000:])
        sys.exit(1)

    frame_files = sorted(f for f in os.listdir(raw_dir) if f.startswith(f"{args.film_short}_raw_"))
    if not frame_files:
        print("Δεν εξήχθη κανένα frame — έλεγξε το path του βίντεο.")
        sys.exit(1)

    rows = []
    prev_hash = None
    prev_id = None

    for fname in frame_files:
        fpath = os.path.join(raw_dir, fname)
        frame_number = int(os.path.splitext(fname)[0].split("_")[-1])
        raw_frame_id = f"{args.film_short}_raw_{frame_number:06d}"

        # timestamp = frame_number(1-indexed) x interval
        total_seconds = (frame_number - 1) * args.interval
        h, m, s = total_seconds // 3600, (total_seconds % 3600) // 60, total_seconds % 60
        timestamp = f"{h:02d}:{m:02d}:{s:02d}"

        img = Image.open(fpath).convert("RGB")
        img_gray = img.convert("L")
        arr_gray = np.asarray(img_gray, dtype=np.float64)

        brightness = round(float(arr_gray.mean()), 2)
        contrast = round(float(arr_gray.std()), 2)
        blur_edge_score = round(compute_blur_edge_score(img_gray), 2)
        phash = compute_average_hash(img_gray)

        duplicate_distance = ""
        duplicate_of = ""
        if prev_hash is not None:
            duplicate_distance = hamming_distance_hex(phash, prev_hash)
            if duplicate_distance <= args.duplicate_threshold:
                duplicate_of = prev_id

        # script_reason / script_suggestion βάσει απλών κατωφλίων -
        # η ομάδα τα επιβεβαιώνει/διορθώνει χειροκίνητα στο Βήμα 3.
        if brightness < args.black_threshold:
            script_reason, script_suggestion = "black_frame", "remove"
        elif contrast < args.low_contrast_threshold:
            script_reason, script_suggestion = "low_contrast", "review"
        elif blur_edge_score < args.blur_threshold:
            script_reason, script_suggestion = "blurred", "review"
        elif duplicate_of:
            script_reason, script_suggestion = "near_duplicate", "review"
        else:
            script_reason, script_suggestion = "usable_candidate", "review"

        rows.append({
            "raw_frame_id": raw_frame_id,
            "raw_filename": f"{raw_dir}/{fname}",
            "frame_number": frame_number,
            "timestamp": timestamp,
            "extraction_rate": f"1 frame / {args.interval} sec",
            "brightness": brightness,
            "contrast": contrast,
            "blur_edge_score": blur_edge_score,
            "perceptual_hash": phash,
            "duplicate_distance": duplicate_distance,
            "duplicate_of": duplicate_of,
            "script_suggestion": script_suggestion,
            "script_reason": script_reason,
            # Τα παρακάτω τα συμπληρώνουμε εμείς χειροκίνητα στο Βήμα 3:
            "final_decision": "",
            "final_reason": "",
            "final_curated_image_id": "",
            "final_curated_filename": "",
            "reviewer": "",
            "comment": "",
        })

        prev_hash, prev_id = phash, raw_frame_id

    os.makedirs("data", exist_ok=True)
    out_path = "data/curation_log.csv"
    pd.DataFrame(rows).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"Δημιουργήθηκαν {len(rows)} raw frames -> {out_path}")
    print("Άνοιξε το curation_log.csv, έλεγξε τα script_suggestion/script_reason "
          "και συμπλήρωσε τα final_decision / final_reason / final_curated_image_id / "
          "final_curated_filename / reviewer / comment (Βήμα 3).")

def build_curated(args):
    print(f"--- Building Curated Dataset: {args.film_title} ---")

    log_path = "data/curation_log.csv"
    if not os.path.exists(log_path):
        print(f"Σφάλμα: Το αρχείο {log_path} δεν βρέθηκε!")
        return

    df = pd.read_csv(log_path)
    kept_df = df[df["final_decision"] == "kept"].copy()

    if kept_df.empty:
        print("Προσοχή: Δεν βρέθηκαν frames με final_decision='kept' στο curation_log.csv")
        return

    missing_ids = kept_df["final_curated_image_id"].isna() | (kept_df["final_curated_image_id"] == "")
    if missing_ids.any():
        print(f"Προσοχή: {missing_ids.sum()} kept γραμμές δεν έχουν final_curated_image_id -- "
              "συμπλήρωσέ τες πριν ξανατρέξεις.")
        return

    curated_dir = "data/images/curated"
    if args.clean_curated_dir and os.path.isdir(curated_dir):
        shutil.rmtree(curated_dir)
    os.makedirs(curated_dir, exist_ok=True)

    # 1) Αντιγραφή/μετονομασία εικόνων στον curated φάκελο 
    copied = 0
    for _, row in kept_df.iterrows():
        src = row["raw_filename"]
        dst_name = row["final_curated_filename"]
        dst = os.path.join(curated_dir, dst_name)
        if os.path.exists(src):
            with Image.open(src) as im:
                im.convert("RGB").save(dst, quality=95)
            copied += 1
        else:
            print(f"  (προειδοποίηση: δεν βρέθηκε raw αρχείο {src})")
    print(f"Αντιγράφηκαν {copied} curated εικόνες -> {curated_dir}/")

    # 2) data/metadata.csv 
    metadata_rows = []
    for _, row in kept_df.iterrows():
        metadata_rows.append({
            "image_id": row["final_curated_image_id"],
            "frame_filename": row["final_curated_filename"],
            "film_title": args.film_title,
            "film_year": args.film_year,
            "source_platform": args.source_platform,
            "source_url": args.source_url,
            "license_status": args.license_status,
            "access_date": args.access_date,
            "timestamp": row["timestamp"],
            "extraction_rate": row["extraction_rate"],
            "curation_decision": row["final_reason"],
            "comments": row["comment"],
        })
    pd.DataFrame(metadata_rows).to_csv("data/metadata.csv", index=False, encoding="utf-8-sig")
    print(f"Δημιουργήθηκε: data/metadata.csv ({len(metadata_rows)} γραμμές)")

    # 3) data/annotations.csv -- template, ΠΡΑΓΜΑΤΙΚΟ σχήμα, ΧΩΡΙΣ bounding boxes ----
    ann_path = "data/annotations.csv"
    if os.path.exists(ann_path) and not args.overwrite_annotations:
        print(f"Το {ann_path} υπάρχει ήδη -- ΔΕΝ αντικαταστάθηκε "
              "(χρησιμοποίησε --overwrite-annotations αν θες να ξαναδημιουργηθεί από την αρχή).")
        return

    ann_rows = []
    for _, row in kept_df.iterrows():
        ann_rows.append({
            "image_id": row["final_curated_image_id"],
            "frame_filename": row["final_curated_filename"],
            "primary_object_label": "",
            "secondary_object_labels": "",
            "narrative_label": "",
            "confidence": "",
            "requires_context": "",
            "annotator_id": "",
            "annotator_notes": "",
        })
    pd.DataFrame(ann_rows).to_csv(ann_path, index=False, encoding="utf-8-sig")
    print(f"Δημιουργήθηκε (κενό) template: {ann_path} ({len(ann_rows)} γραμμές) -- "
          "συμπλήρωσέ το χειροκίνητα στο annotation (Βήμα 7).")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="action")

    # Mode 1: extract_preprocess
    ep = subparsers.add_parser("extract_preprocess")
    ep.add_argument("--video", required=True)
    ep.add_argument("--film-short", required=True)
    ep.add_argument("--interval", type=int, default=10)
    ep.add_argument("--duplicate-threshold", type=int, default=5,
                     help="Hamming distance <= αυτό -> θεωρείται near-duplicate.")
    ep.add_argument("--black-threshold", type=float, default=15.0,
                     help="brightness κάτω από αυτό -> black_frame.")
    ep.add_argument("--low-contrast-threshold", type=float, default=10.0)
    ep.add_argument("--blur-threshold", type=float, default=50.0)

    build_p = subparsers.add_parser("build_curated")
    build_p.add_argument("--film-short", required=True)
    build_p.add_argument("--film-title", required=True)
    build_p.add_argument("--film-year", required=True)
    build_p.add_argument("--source-platform", required=True)
    build_p.add_argument("--source-url", required=True)
    build_p.add_argument("--license-status", required=True)
    build_p.add_argument("--access-date", required=True)
    build_p.add_argument("--overwrite-annotations", action="store_true")
    build_p.add_argument("--clean-curated-dir", action="store_true")

    args = parser.parse_args()

    if args.action == "extract_preprocess":
        extract_preprocess(args)
    elif args.action == "build_curated":
        build_curated(args)
    else:
        parser.print_help()
