import argparse
import os
import pandas as pd

def build_curated(args):
    print(f"--- Building Curated Dataset: {args.film_title} ---")

    log_path = 'data/curation_log.csv'
    if not os.path.exists(log_path):
        print(f"Σφάλμα: Το αρχείο {log_path} δεν βρέθηκε!")
        return

    # Διάβασμα του log
    df = pd.read_csv(log_path)
    # Κρατάμε μόνο τα frames που σημείωσες ως 'kept'
    kept_df = df[df['final_decision'] == 'kept'].copy()

    if kept_df.empty:
        print("Προσοχή: Δεν βρέθηκαν frames με decision 'kept' στο curation_log.csv")
        return

    # 1. Δημιουργία data/metadata.csv
    metadata = []
    for _, row in kept_df.iterrows():
        metadata.append({
            'image_id': row['final_curated_image_id'],
            'film_short': args.film_short,
            'film_title': args.film_title,
            'year': args.film_year,
            'license': args.license_status,
            'source_url': args.source_url
        })

    pd.DataFrame(metadata).to_csv('data/metadata.csv', index=False, encoding='utf-8-sig')
    print("Δημιουργήθηκε το αρχείο: data/metadata.csv")

    # 2. Δημιουργία data/annotations.csv (Template)
    ann_path = 'data/annotations.csv'
    if not os.path.exists(ann_path) or args.overwrite_annotations:
        ann_df = pd.DataFrame(columns=['image_id', 'label', 'xmin', 'ymin', 'xmax', 'ymax'])
        ann_df['image_id'] = kept_df['final_curated_image_id']
        ann_df.to_csv(ann_path, index=False, encoding='utf-8-sig')
        print("Δημιουργήθηκε το αρχείο: data/annotations.csv")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="action")

    # Mode 1: extract_preprocess (για συμβατότητα)
    subparsers.add_parser("extract_preprocess")

    # Mode 2: build_curated (αυτό που ζητάει η εκφώνηση στο Βήμα 3)
    build_p = subparsers.add_parser("build_curated")
    build_p.add_argument("--film-short", required=True)
    build_p.add_argument("--film-title", required=True)
    build_p.add_argument("--film-year", required=True)
    build_p.add_argument("--source-platform", required=True)
    build_p.add_argument("--source-url", required=True)
    build_p.add_argument("--license-status", required=True)
    build_p.add_argument("--access-date", required=True)
    build_p.add_argument("--overwrite-annotations", action="store_true")
    build_p.add_argument("--clean-curated-dir", action="store_true") # Προσθήκη για συμβατότητα με την εντολή

    args = parser.parse_args()

    if args.action == "build_curated":
        build_curated(args)
    else:
        print("Action: extract_preprocess executed (No changes made).")
