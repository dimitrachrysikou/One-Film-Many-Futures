# Dataset Card — One Film, Many Futures: *House on Haunted Hill* (1959)

## 1. Βασικά Στοιχεία & Ταυτότητα dataset

Ομάδα                 : Group 15 — Χρυσικού Δήμητρα / 2022202300179, Δημόπουλος Νικόλαος / 2022202300218
Όνομα dataset         : One Film, Many Futures — House on Haunted Hill 
Ταινία                : *House on Haunted Hill* (1959) 
Πηγή υλικού           : Internet Archive — https://archive.org/details/HouseOnHauntedHill1959
Ημερομηνία πρόσβασης  : 2026-05-19 
Όγκος δεδομένων       : 130 curated frames (από 447 raw extracted frames) 
Ρυθμός δειγματοληψίας : 1 frame / 10 sec (διάρκεια ταινίας 1:14:33) 
Μορφή επισημείωσης    : Frame-level semantic annotation (χωρίς bounding boxes) 
Κατάσταση δικαιωμάτων : Public-domain claim by source (US)· βλ. `docs/source_rights_memo.md` 

## 2. Περιγραφή & Ερευνητικός Σκοπός

Το dataset περιλαμβάνει 130 επιμελημένα frames από την ταινία *House on Haunted Hill* (1959). Δημιουργήθηκε για να εξετάσει πώς ο κινηματογράφος της δεκαετίας του '50 οργανώνει οπτικά τον τρόμο, το υπερφυσικό, τη γοτθική αρχιτεκτονική και το ανθρώπινο σώμα υπό συναισθηματική πίεση μέσα από έντονες αντιθέσεις φωτός/σκιάς και εξειδικευμένα σκηνικά αντικείμενα. Κάθε frame φέρει primary object label, secondary labels, narrative label, confidence και requires_context.

## 3. Αρχιτεκτονική & Δομή Αρχείων

`data/images/curated/`            -->   130 τελικά frames (house_XXXXXX.jpg)
`data/metadata.csv`               -->   1 γραμμή ανά curated frame (ταυτότητα, πηγή, timestamp)
`data/curation_log.csv`           -->   audit trail και για τα 447 raw frames (kept/removed + λόγος)
`data/annotations.csv`            -->   frame-level labels για τα 130 frames
`data/double_annotation_log.csv`  -->   26 frames (20.0%) με διπλή επισημείωση
`data/yolo_audit_results.csv`     -->   audit YOLOv8n σε 50 frames
`docs/`                           -->   source_rights_memo, taxonomy, labeling_guidelines

## 4. Πλαίσιο Ταξινομίας

**Οπτικές κατηγορίες (6):** Human_Body, Artificial_Threat, Period_Prop, Threshold_Element, Shadow_Entity, Unknown_Ambiguous. Πλήρεις ορισμοί και κριτήρια στο `docs/taxonomy.md`.

**Narrative κατηγορίες (6):** Terror_expression,Supernatural_Suggestion, Body_Vulnerability, Gothic_Atmosphere, Imprisonment_Theme, Plot_Exposition.

**Η ταξινομία σχεδιάστηκε εξαρχής για το είδος του horror:** αντικατέστησε γενικές ετικέτες (όπως "person") με κατηγορίες που εστιάζουν στη σωματικότητα, τα ιστορικά props (π.χ. πολυέλαιοι, κηροπήγια) και τις τεχνητές ή μεταφυσικές απειλές της πλοκής.

## 5. Ποσοτική Κατανομή Επισημειώσεων

**Primary object label  | Frames** 

Human_Body              :   80
Artificial_Threat       :   12
Period_Prop             :   18
Threshold_Element       :   15
Shadow_Entity           :   4
Unknown_Ambiguous       :   1

**Narrative label       | Frames** 

Terror_Expression       :   17
Supernatural_Suggestion :   5   
Body_Vulnerability      :   13
Gothic_Atmosphere       :   29
Imprisonment_Theme      :   2
Plot_Exposition         :   64         


**Confidence:** 126 high / 2 medium / 2 low. 
**Requires_context = yes** σε 8 frames.

## 6. Διαδικασία Επισημείωσης & Διπλός Έλεγχος

Δύο annotators επισημείωσαν το υλικό. 26 frames (20.0%) επισημειώθηκαν ανεξάρτητα και από τους δύο για τον έλεγχο της υποκειμενικότητας: 11 συμφωνίες και 15 διαφωνίες Όλες οι διαφωνίες (που ανέδειξαν την ερμηνευτική πολυπλοκότητα μεταξύ οπτικού αντικειμένου και ατμόσφαιρας) καταγράφηκαν και επιλύθηκαν μέσω συζήτησης στο `double_annotation_log.csv`.

## 7. Αξιολόγηση Αυτόματου Ανιχνευτή (YOLOv8 Audit)

Αποτελέσματα: 16 correct_detection, 11 misclassified_object, 10 missed_object, 6 irrelevant_detection, 6 model_category_missing, 1 partial_detection. Το μοντέλο παρουσίασε σημαντικές αδυναμίες (πολλά misclassified_object σημαίνει ότι το YOLO βλέπει κάτι αλλά το ονομάζει λάθος λόγω vintage αντικειμένων, ενώ model_category_missing δείχνει ότι το λεξιλόγιο COCO απλά δεν έχει κατηγορίες σαν horror props).

## 8. Ενδεδειγμένες Εφαρμογές

- Ακαδημαϊκή μελέτη των συστημικών προκαταλήψεων μοντέλων Computer Vision σε ασπρόμαυρο ιστορικό κινηματογραφικό υλικό.
- Ανάλυση της σκηνοθεσίας, της χρήσης του φωτός και των props στον αμερικανικό κινηματογράφο τρόμου της δεκαετίας του 1950.

## 9. Ακατάλληλες Χρήσεις & Απαγορεύσεις

- Εκπαίδευση παραγωγικών μοντέλων AI ή Generative AI (λόγω μικρού δείγματος και ερμηνευτικής φύσης των labels).
- Δημόσια αναδιανομή: λόγω αβεβαιότητας δικαιωμάτων βάσει ευρωπαϊκής νομοθεσίας (Life + 70), το dataset υποβάλλεται αποκλειστικά για το μάθημα.

## 10. Εγγενείς Περιορισμοί Δεδομένων

- Η δειγματοληψία ανά 10 δευτερόλεπτα ενδέχεται να χάνει στιγμιαία jump scares ή γρήγορες αλλαγές δράσης.
- Τα αφηγηματικά labels είναι ερμηνευτικά και αντανακλούν τις συναινετικές αποφάσεις της ομάδας.
- Η αφαίρεση των εντελώς σκοτεινών frames κατά το curation οδηγεί σε υποεκπροσώπηση του απόλυτου σκότους στο τελικό dataset.