# One Film, Many Futures - Curated Horror Dataset & AI Audit

**Μάθημα:** Δημιουργική Πληροφορική και Τέχνη Νέων Μέσων (Πανεπιστήμιο Πελοποννήσου)  
**Ακαδημαϊκό Έτος:** 2025 – 2026  
**Ταινία:** *House on Haunted Hill* (1959)

## Περιγραφή Project
Το παρόν project εστιάζει στη δημιουργία ενός επιμελημένου (curated) dataset εικόνων από ιστορικό κινηματογραφικό υλικό τρόμου. Στόχος είναι η αντιπαραβολή της ανθρώπινης ερμηνείας (αφηγηματικά και σκηνοθετικά labels) με τη "μηχανική" όραση ενός γενικού αλγορίθμου Τεχνητής Νοημοσύνης. Μέσα από την εργασία αυτή καταγράφεται το τι "βλέπει" και τι "παρεξηγεί" το μοντέλο YOLOv8 όταν αναλύει ασπρόμαυρα frames με έντονες σκιές, γοτθική ατμόσφαιρα και vintage σκηνικά αντικείμενα (props).

## Δομή Φακέλων
Η οργάνωση των αρχείων ακολουθεί την παρακάτω δομή:

├── code/                               # Scripts και κώδικας
│   ├── preprocessing-script.py         # Το script προεπεξεργασίας και κατασκευής του curated dataset
│   └── run_yolo_audit.txt              # Η εντολή CLI που χρησιμοποιήθηκε για την εκτέλεση του YOLO
│
├── data/                               # Ο κεντρικός φάκελος με τα δεδομένα του dataset
│   ├── images/
│   │   ├── audit_sample/               # 50 επιλεγμένα καθαρά frames για τον έλεγχο του AI
│   │   └── curated/                    # Τα 130 τελικά επιλεγμένα frames της ταινίας   
│   ├── annotations.csv                 # Τα ανθρώπινα (human) labels για όλα τα frames
│   ├── curation_log.csv                # Καταγραφή της επιλογής (ποια frames κρατήθηκαν/διαγράφηκαν και γιατί)
│   ├── double_annotation_log.csv       # Αρχείο με τα 30 frames διπλού σχολιασμού και την επίλυση των διαφωνιών
│   ├── metadata.csv                    # Μεταδεδομένα των frames (π.χ. χρονοσήμανση, όνομα αρχείου)
│   └── yolo_audit_results.csv          # Η τελική αξιολόγηση και σύγκριση (YOLO predictions vs Human labels)
│
├── docs/                               # Βοηθητική τεκμηρίωση του project
│   ├── labeling_guidelines.md          # Οδηγίες και κανόνες που ακολουθήθηκαν για το χειροκίνητο annotation
│   ├── source_rights_memo.md           # Αναφορά στα πνευματικά δικαιώματα (Public Domain) της ταινίας
│   └── taxonomy.md                     # Αναλυτική περιγραφή των προσαρμοσμένων κατηγοριών (Horror labels)
│
├── outputs/                            # Εξαγόμενα αρχεία από την εκτέλεση του μοντέλου
│   └── yolo_annotated_examples/        # Οπτικά παραδείγματα (εικόνες) με τα bounding boxes που παρήγαγε το YOLO
│
├── dataset_card.md                     # Συνοπτική κάρτα χαρακτηριστικών του dataset
├── datasheet_report.pdf                # Αναλυτική τεκμηρίωση της μεθοδολογίας και του dataset
└── README.md                           # Το παρόν αρχείο (οδηγός πλοήγησης στο repository)

## Τεχνολογίες & Εγκατάσταση
Για την αναπαραγωγή του Object Detection Audit χρησιμοποιήθηκε η βιβλιοθήκη Ultralytics YOLOv8. Προτείνεται η χρήση Python Virtual Environment (venv).

Οδηγίες Εγκατάστασης:

1. Δημιουργία και ενεργοποίηση virtual environment:

python -m venv .venv

# Για Windows:
.venv\Scripts\activate

# Για macOS/Linux:
source .venv/bin/activate

2. Εγκατάσταση των απαιτούμενων πακέτων:
python -m pip install --upgrade pip
python -m pip install ultralytics

# Διαδικασία Προεπεξεργασίας (Google Colab Pipeline)
Για την αρχική συγκρότηση του dataset χρησιμοποιήθηκε το script προεπεξεργασίας code/preprocessing-script.py στο περιβάλλον του Google Colab.
Το script εκτελεί αυτόματα το φιλτράρισμα του curation_log.csv (απομονώνοντας τα frames με ένδειξη kept) και παράγει τον βασικό σκελετό-template για τα αρχεία metadata.csv και annotations.csv.

* Η εντολή που εκτελέστηκε στο Colab για το χτίσιμο του dataset:
python code/preprocessing-script.py build_curated \
  --film-short "hohh59" \
  --film-title "House on Haunted Hill" \
  --film-year "1959" \
  --source-platform "Internet Archive" \
  --source-url "[https://archive.org/details/HouseOnHauntedHill](https://archive.org/details/HouseOnHauntedHill)" \
  --license-status "Public Domain" \
  --access-date "2026-05-19" \
  --clean-curated-dir

Σημείωση: Τα παραγόμενα αρχεία .csv υπέστησαν στη συνέχεια εκτενή χειροκίνητο έλεγχο, ποιοτικό καθαρισμό και προσθήκη των εξειδικευμένων δικών μας labels (Human Ground Truth), όπως περιγράφεται στο datasheet_report.pdf.

# Εκτέλεση YOLO Audit
Για την παραγωγή των αποτελεσμάτων στον φάκελο outputs/, εκτελέστηκε η παρακάτω εντολή από το τερματικό:
yolo predict model=yolov8n.pt source=data/images/audit_sample save=True save_txt=True save_conf=True conf=0.25 project=outputs name=yolo_annotated_examples

# Ταξινομία (Taxonomy)
Για τις ανάγκες του annotation, αναπτύχθηκε ένα εξειδικευμένο λεξιλόγιο προσαρμοσμένο στο είδος του Horror:

Human_Body: Σωματικότητα και παρουσία των χαρακτήρων.

Period_Prop: Ιστορικά σκηνικά αντικείμενα (π.χ. κηροπήγια, έπιπλα αντίκες).

Artificial_Threat: Κατασκευασμένες απειλές της πλοκής (π.χ. σκελετός).

Supernatural_Suggestion: Αφηγηματικά στοιχεία που υποδηλώνουν το υπερφυσικό (π.χ. σκιές).

# Συντελεστές
Μέλος Α: Χρυσικού Δήμητρα / 2022202300179

Μέλος Β: Δημόπουλος Νικόλαος / 2022202300218
(Η αναλυτική ατομική συνεισφορά περιγράφεται στο datasheet_report.pdf)