# One Film, Many Futures - Curated Horror Dataset & AI Audit

**Μάθημα:** Δημιουργική Πληροφορική και Τέχνη Νέων Μέσων (Πανεπιστήμιο Πελοποννήσου)  
**Ακαδημαϊκό Έτος:** 2025 – 2026  
**Ομάδα:** 15
**Ταινία:** *House on Haunted Hill* (1959)
**Ημερομηνία πρόσβασης:** 2026-05-19
**Πηγή υλικού:** Internet Archive — https://archive.org/details/HouseOnHauntedHill1959

## Περιγραφή Project
Το παρόν project εστιάζει στη δημιουργία ενός επιμελημένου (curated) dataset εικόνων από ιστορικό κινηματογραφικό υλικό τρόμου. Στόχος είναι η αντιπαραβολή της ανθρώπινης ερμηνείας (αφηγηματικά και σκηνοθετικά labels) με τη "μηχανική" όραση ενός γενικού αλγορίθμου Τεχνητής Νοημοσύνης (YOLOv8). Μέσα από την εργασία αυτή καταγράφεται το τι "βλέπει" και τι "παρεξηγεί" το μοντέλο YOLOv8 όταν αναλύει ασπρόμαυρα frames με έντονες σκιές, γοτθική ατμόσφαιρα και vintage σκηνικά αντικείμενα.

## Δομή Φακέλων
Η οργάνωση των αρχείων ακολουθεί την παρακάτω δομή:

one_film_many_futures_group15/
├── code/                               # Scripts και κώδικας
│   ├── preprocessing-script.py         # Το script προεπεξεργασίας και κατασκευής του curated dataset
│   └── run_yolo_audit.txt              # Η εντολή CLI που χρησιμοποιήθηκε για την εκτέλεση του YOLO
│
├── data/                               # Ο κεντρικός φάκελος με τα δεδομένα του dataset
│   ├── images/
│   │   ├── audit_sample/               # 50 επιλεγμένα καθαρά frames για τον έλεγχο του AI
│   │   └── curated/                    # Τα 130 τελικά επιλεγμένα frames της ταινίας   
│   ├── annotations.csv                 # Τα ανθρώπινα (human) labels για όλα τα frames
│   ├── curation_log.csv                # Καταγραφή της επιλογής (ποια frames κρατήθηκαν/διαγράφηκαν και γιατί)
│   ├── double_annotation_log.csv       # Αρχείο με τα 26 frames διπλού σχολιασμού και την επίλυση των διαφωνιών
│   ├── metadata.csv                    # Μεταδεδομένα των frames (π.χ. χρονοσήμανση, όνομα αρχείου)
│   └── yolo_audit_results.csv          # Η τελική αξιολόγηση και σύγκριση (YOLO predictions vs Human labels)
│
├── docs/                               # Βοηθητική τεκμηρίωση του project
│   ├── labeling_guidelines.md          # Οδηγίες και κανόνες που ακολουθήθηκαν για το χειροκίνητο annotation
│   ├── source_rights_memo.md           # Αναφορά στα πνευματικά δικαιώματα (Public Domain) της ταινίας
│   └── taxonomy.md                     # Αναλυτική περιγραφή των προσαρμοσμένων κατηγοριών (Horror labels)
│
├── outputs/                            # Εξαγόμενα αρχεία από την εκτέλεση του μοντέλου
│   └── yolo_annotated_examples/        # Οπτικά παραδείγματα (εικόνες) με τα bounding boxes που παρήγαγε το YOLO
│
├── raw_frames/                         # 447 raw extracted frames (προαιρετικό, για αναπαραγωγή)
│
├── dataset_card.md                     # Συνοπτική κάρτα χαρακτηριστικών του dataset
├── datasheet_report.pdf                # Αναλυτική τεκμηρίωση της μεθοδολογίας και του dataset
└── README.md                           # Το παρόν αρχείο (οδηγός πλοήγησης στο repository)

## Αναλυτική Περιγραφή Βημάτων & Αρχείων

**Βήμα 1 — Πηγή & Δικαιώματα (source_rights_memo.md)**
docs/source_rights_memo.md: Τεκμηρίωση της πηγής (Internet Archive), του Public Domain status στις ΗΠΑ και της νομικής επιφύλαξης (jurisdiction note) για την ισχύουσα νομοθεσία πνευματικών δικαιωμάτων στην Ελλάδα/ΕΕ (Life + 70 έτη).

**Βήμα 2 — Εξαγωγή Frames & Curation Log**
code/preprocessing-script.py: Script σε Python που εκτελεί frame extraction ανά 10 δευτερόλεπτα και υπολογίζει αυτόματα τεχνικούς δείκτες (brightness, contrast, blur score).

data/curation_log.csv: Audit trail καταγραφής και των 447 αρχικών raw frames. Κατανομή αποφάσεων:
Kept: 130 frames
Removed: 317 frames (λόγοι: pitch-black frames, θολά καρέ, credits, κοντινές επαναλήψεις).

**Βήμα 3 — Curated Dataset & Μεταδεδομένα**
data/metadata.csv: Περιλαμβάνει 130 γραμμές (μία ανά curated frame) με μοναδικό image_id, filename, timestamp ταινίας, πηγή και στοιχεία αναπαραγωγής.

**Βήμα 4 — Εξειδικευμένη Ταξινομία (taxonomy.md)**
docs/taxonomy.md: Σύστημα κατηγοριών προσαρμοσμένο στον κινηματογράφο τρόμου της δεκαετίας του '50:
- 6 Οπτικές κατηγορίες: Human_Body (80), Period_Prop (18), Threshold_Element (15), Artificial_Threat (12), Shadow_Entity (4), Unknown_Ambiguous (1).

- 6 Αφηγηματικές κατηγορίες: Plot_Exposition (64), Gothic_Atmosphere (29), Terror_Expression (17), Body_Vulnerability (13), Supernatural_Suggestion (5), Imprisonment_Theme (2).

**Βήμα 5 — Οδηγίες Επισημείωσης (labeling_guidelines.md)**
docs/labeling_guidelines.md: Κανόνες επιλογής primary/secondary labels, διαχείριση αμφισημίας (Unknown_Ambiguous), κριτήρια για το πότε απαιτείται πλαίσιο (requires_context = yes) και ορισμός επιπέδων βεβαιότητας (confidence).

**Βήμα 6 — Επισημείωση Δεδομένων (annotations.csv)**
data/annotations.csv: Τα ανθρώπινα ground truth labels για τα 130 frames.

- Confidence: High: 126 frames | Medium: 2 frames | Low: 2 frame.
- Requires Context = yes: 8 frames.

**Βήμα 7 — Διπλή Επισημείωση & Ανάλυση Διαφωνιών (double_annotation_log.csv)**
data/double_annotation_log.csv: 26 frames (20.0% του dataset) επισημειώθηκαν ανεξάρτητα και από τα δύο μέλη της ομάδας.

- Αποτελέσματα: 11 συμφωνίες και 15 διαφωνίες.
- Ανάλυση: Οι διαφωνίες αφορούσαν κυρίως τα όρια μεταξύ οπτικού αντικειμένου (π.χ. αρχιτεκτονικό στοιχείο) και αφηγηματικής ατμόσφαιρας. Όλες οι διαφωνίες επιλύθηκαν με συζήτηση και καταγράφηκε το σκεπτικό.

**Βήμα 8 — Έλεγχος Αυτόματου Ανιχνευτή (YOLO Audit)**
code/run_yolo_audit.txt: Η ακριβής εντολή CLI που εκτελέστηκε.
data/yolo_audit_results.csv: Αξιολόγηση του YOLOv8n σε δείγμα 50 frames.

- Αποτελέσματα: Αποτελέσματα: 16 correct_detection, 11 misclassified_object, 10 missed_object, 6 irrelevant_detection, 6 model_category_missing, 1 partial_detection. 
- Βασικό συμπέρασμα: πολλά misclassified_object σημαίνει ότι το YOLO βλέπει κάτι αλλά το ονομάζει λάθος λόγω vintage αντικειμένων, ενώ model_category_missing δείχνει ότι το λεξιλόγιο COCO απλά δεν έχει κατηγορίες σαν horror props. 

**Βήμα 9 — Τεκμηρίωση (dataset_card.md & datasheet_report.pdf)**
dataset_card.md: Σύντομη κάρτα ταυτότητας του dataset.

datasheet_report.pdf: Πλήρες report 13 σελίδων βασισμένο στο πρότυπο Datasheets for Datasets, με αναλυτικά παραδείγματα και ατομική συνεισφορά.

## Τεχνολογίες & Εγκατάσταση
Για την αναπαραγωγή του Object Detection Audit χρησιμοποιήθηκε η βιβλιοθήκη Ultralytics YOLOv8. Προτείνεται η χρήση Python Virtual Environment (venv).

Οδηγίες Εγκατάστασης:

1. Δημιουργία και ενεργοποίηση virtual environment:

python -m venv .venv

# Για Windows:
.venv\Scripts\activate

# Για macOS/Linux:
source .venv/bin/activate

2. Εγκατάσταση των απαιτούμενων πακέτων:
python -m pip install --upgrade pip
python -m pip install ultralytics

# Διαδικασία Προεπεξεργασίας (Google Colab Pipeline)
Για την αρχική συγκρότηση του dataset χρησιμοποιήθηκε το script προεπεξεργασίας code/preprocessing-script.py στο περιβάλλον του Google Colab.
Το script εκτελεί αυτόματα το φιλτράρισμα του curation_log.csv (απομονώνοντας τα frames με ένδειξη kept) και παράγει τον βασικό σκελετό-template για τα αρχεία metadata.csv και annotations.csv.

**Η εντολή που εκτελέστηκε στο Colab για το χτίσιμο του dataset:**
python code/preprocessing-script.py build_curated \
  --film-short "hohh59" \
  --film-title "House on Haunted Hill" \
  --film-year "1959" \
  --source-platform "Internet Archive" \
  --source-url "https://archive.org/details/HouseOnHauntedHill1959" \
  --license-status "Public Domain" \
  --access-date "2026-05-19" \
  --clean-curated-dir

Σημείωση: Τα παραγόμενα αρχεία .csv υπέστησαν στη συνέχεια εκτενή χειροκίνητο έλεγχο, ποιοτικό καθαρισμό και προσθήκη των εξειδικευμένων δικών μας labels, όπως περιγράφεται στο datasheet_report.pdf.

## Εκτέλεση YOLO Audit
Για την παραγωγή των αποτελεσμάτων στον φάκελο outputs/, εκτελέστηκε η παρακάτω εντολή από το τερματικό:
yolo predict model=yolov8n.pt source=data/images/audit_sample save=True save_txt=True save_conf=True conf=0.25 project=outputs name=yolo_annotated_examples

## Περιορισμοί & Ειδικές Επισημάνσεις
**Μέγεθος Δείγματος:** Το dataset αποτελείται από 130 curated frames μιας συγκεκριμένης ταινίας. Ενδείκνυται για ποιοτική ανάλυση και ερευνητικό έλεγχο προκαταλήψεων AI, όχι για εκπαίδευση παραγωγικών μοντέλων.
**Ερμηνευτικός Χαρακτήρας:** Τα αφηγηματικά labels αντανακλούν τη συναινετική ερμηνεία της ομάδας και δεν αποτελούν αντικειμενικές «αλήθειες».
**Πνευματικά Δικαιώματα:** Το υλικό διατίθεται αποκλειστικά για εκπαιδευτική/ακαδημαϊκή χρήση στο πλαίσιο του μαθήματος.

## Συντελεστές
**Μέλος Α:** Χρυσικού Δήμητρα / 2022202300179
**Μέλος Β:** Δημόπουλος Νικόλαος / 2022202300218
(Η αναλυτική ατομική συνεισφορά περιγράφεται στο datasheet_report.pdf)

## Ακαδημαϊκές Αναφορές
- Gebru, T., Morgenstern, J., Vecchione, B., Vaughan, J. W., Wallach, H., Daumé III, H., & Crawford, K. (2021). Datasheets for datasets. Communications of the ACM, 64(12), 86-92.

- Buolamwini, J., & Gebru, T. (2018). Gender shades: Intersectional accuracy disparities in commercial gender classification. Conference on Fairness, Accountability and Transparency (FAT*), 77-91.